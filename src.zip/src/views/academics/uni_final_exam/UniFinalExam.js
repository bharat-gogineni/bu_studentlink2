import React from 'react'

const UniFinalExam = () => {
  return (
    <div
      dangerouslySetInnerHTML={{
        __html: `<table>
        <tbody><tr valign="bottom">
          <th colspan="3"><font size="-1">Class
          </font></th><th>          <font size="-1">Title
          </font></th><th>          <font size="-1">Instructor
          </font></th><th>          <font size="-1">Enroll  
          </font></th><th colspan="2"><font size="-1">Exam Date
          </font></th><th><font size="-1">Time
          </font></th><th colspan="2"><font size="-1">Location
          </font></th><th colspan="3" align="CENTER"><font size="-1">Group Exams
          </font></th><th colspan="1" align="CENTER"><font size="-1">Final Exam Comment
        
        
        
        </font></th></tr><tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD510</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MATH STAT&amp;MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RITT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  23</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">225</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD571</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BUS ANALYTICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RITT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  42</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">216</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD571</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BUS ANALYTICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ORUNKHANOV</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  33</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">237</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD571</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BUS ANALYTICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">KIM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">235</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD610</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ENTER RISK MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CARROLL</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  31</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">326</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD610</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ENTER RISK MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WEIDMAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  11</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">212</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD616</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ENT RISK ANALTI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">KIM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  40</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">152</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD616</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ENT RISK ANALTI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RITT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">201</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD617</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BUS CONT MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WEIDMAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  15</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MCS">MCS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B37</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD630</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FIN &amp; MGR ACCNT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BARSKAYA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  38</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">212</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD630</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FIN &amp; MGR ACCNT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MENDLINGER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  48</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD630</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FIN &amp; MGR ACCNT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RINALDI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  42</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">123</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD630</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FIN &amp; MGR ACCNT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BARSKAYA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  46</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD630</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A6</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FIN &amp; MGR ACCNT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">KANZA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B33</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD632</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FINAN CONCEPTS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NOORIAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  41</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SOC">SOC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B63</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD632</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FINAN CONCEPTS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MCGUE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  24</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">222</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG472</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd="></a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG472</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD632</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FINAN CONCEPTS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MCGUE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  47</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD632</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FINAN CONCEPTS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MCGUE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  48</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD632</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A5</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FINAN CONCEPTS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MCGUE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  47</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">527</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD632</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A7</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FINAN CONCEPTS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">KANZA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  44</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=EPC">EPC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">204</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD642</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PROJECT MANGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GREIMAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  46</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Sat</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/18/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD642</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PROJECT MANGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">KEEGAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  34</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">226</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD642</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A5</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PROJECT MANGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CIPRIANO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  30</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SCI">SCI</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">115</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD642</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A6</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PROJECT MANGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">KEEGAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  30</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=EPC">EPC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">203</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD644</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PROJ RISK/COST</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BELACK</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   9</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PHO">PHO</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">201</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD648</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ECOMMERCE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">APPELTANS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  48</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD648</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ECOMMERCE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SHAPIRO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  44</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B36</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD649</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AGILE PROJ MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HANNON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  28</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MCS">MCS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B29</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD654</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MKTG ANALYTICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PAGE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  48</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Sat</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/18/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STH">STH</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B19</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD654</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MKTG ANALYTICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PAGE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  16</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">426</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD655</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTL BUS EC CUL</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GONCALVES</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  43</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">315</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD655</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTL BUS EC CUL</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GIL VASQUEZ</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  29</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">226</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD655</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTL BUS EC CUL</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GONCALVES</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  33</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">525</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD667</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INNOV&amp;NATL ECON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RAHMAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  14</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B53</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD678</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FIN REG ÐICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">STODDER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  45</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD678</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FIN REG ÐICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SHIMER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  46</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">324</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD680</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GLOB SPLY CHAIN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GANCI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  42</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">212</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD680</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GLOB SPLY CHAIN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GUNES CORLU</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  47</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD685</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FINAN QUAN METH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">VILLANUEVA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  46</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">326</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD685</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FINAN QUAN METH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">JULIO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  48</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD685</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FINAN QUAN METH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">JULIO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  31</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Fri</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/17/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">525</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD690</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">STRAT LOG MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GLASS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  11</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SOC">SOC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B63</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD699</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DATA MINING</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PAGE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  22</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD699</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DATA MINING</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PAGE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   5</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">237</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD709</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CSE ST CORP FIN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SULLIVAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  13</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">226</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD712</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FIN MARK&amp;INST</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AHMED</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  12</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">324</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD712</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FIN MARK&amp;INST</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AHMED</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  27</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STH">STH</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">113</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD713</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DER,SEC &amp; MKTS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">VODENSKA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  34</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Sat</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/18/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD714</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MERGERS &amp; ACQ</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SULLIVAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  34</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">213</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD714</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MERGERS &amp; ACQ</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ZAFIROPOULOS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  14</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MCS">MCS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B29</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD715</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">QUAN&amp;QUALDECMKG</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ZLATEV</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  45</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD715</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A5</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">QUAN&amp;QUALDECMKG</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ZLATEV</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  45</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Fri</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/17/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD717</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INVANALPORTMGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BECKER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  33</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD717</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INVANALPORTMGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BECKER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  17</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=COM">COM</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">213</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD719</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FIX INCOME ANLS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CHEE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  17</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STH">STH</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B20</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD731</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CORP FINANCE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ENGLANDER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  48</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD731</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CORP FINANCE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CHEE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  34</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=EPC">EPC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">206</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD731</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CORP FINANCE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MENDLINGER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  42</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SOC">SOC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B57</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD731</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CORP FINANCE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BARAZI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  42</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MCS">MCS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B29</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD734</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">QUALITY MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MALEYEFF</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  26</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">222</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD737</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INNOVT MKT TECH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BABB</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  42</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD741</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INNOVATION PROC</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PARK</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  48</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD746</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BUSLAW® GLOB</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BARRY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">216</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG550</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD763</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MULTINAT FINANC</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SHERMAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B51</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD856</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MK&amp;EC RSRCH&amp;ANA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GONCALVES</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  37</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">324</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD899</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAPSTONE IN ABA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ZLATEV</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SHA">SHA</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">202</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AH216</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BASIC DIG PHOTO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HAINES</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  14</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SOC">SOC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B65</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AH315</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HIST OF PHOTO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HAINES</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  11</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B49</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AN102</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HUMAN BIOLOGY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MUSTAFA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  11</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">335</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AR720</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MK+AUD DVLP ART</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PETERSON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  20</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">208</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AR730</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">POL &amp; PUB ADVOC</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RUDDOCK</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   7</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">229</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AR778</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LGL ISS ART ADM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BLACKADAR</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  15</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">326</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AR789</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CULTURAL ENTREP</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GROSSMAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  23</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B53</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AT602</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LAB AT FIN 2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PATASHNICK</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  14</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Sat</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/18/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">221</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AT602</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LAB AT FIN 2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PATASHNICK</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Sat</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/18/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">221</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AT721</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MATH CMPD INT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PATASHNICK</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   9</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STH">STH</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">318</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AT721</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MATH CMPD INT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HORWITZ</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  10</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STH">STH</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">318</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AT722</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FINANCE FOR AT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NOH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  10</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B47</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AT732</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ACTURL MATH 2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">TEPFER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  11</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B47</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AT741</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ACTURL STATS 1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">TEPFER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  16</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">116</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AT751</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INS APP AT 1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HORWITZ</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  16</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Sat</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/18/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">423</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AT752</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INS APP AT 2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SILVERMAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  13</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SOC">SOC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B59</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AT762</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MATH FINANCE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PATASHNICK</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  17</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B45</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BI107</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BIOLOGY 1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LAVALLI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   9</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">423</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BI211</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HUMAN PHYSIOLOG</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">VYSHEDSKIY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   5</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=BRB">BRB</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">121</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BI366</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NEUROSCI COGNIT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">VYSHEDSKIY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  22</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=BRB">BRB</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BI407</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ANIMAL BEHAVIOR</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WASSERMAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  16</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PRB">PRB</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">146</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GEN CHEM 1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ABRAMS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MOR">MOR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">129</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=LAW">LAW</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AUD</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SCI">SCI</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">109</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A4</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STO">STO</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B50</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH102</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GEN CHEM 2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DILL</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   5</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Fri</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/17/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">313</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH102</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">315</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH171</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PRINC GEN CHEM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SZYMCZYNA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   0</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SCI">SCI</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">109</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH171</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH203</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ORGANIC CHEM 1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WHITTY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   7</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">105</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH203</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=COM">COM</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH203</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=KCB">KCB</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH203</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PHO">PHO</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">206</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH218</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">522</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH218</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SAR">SAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH218</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">511</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH351</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PHYSICAL CHEM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">STRAUB</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   0</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">313</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH351</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH373</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PRINC BIOCHEM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SZYMCZYNA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SCI">SCI</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">109</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH373</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STO">STO</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B50</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH421</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BIOCHEMISTRY 1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">TOLAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   0</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STO">STO</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B50</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BI421</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd="></a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GRS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BI621</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd="></a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH421</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd="></a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GRS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH621</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH421</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BIOCHEMISTRY 1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WHITTY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MOR">MOR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BI421</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd="></a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GRS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BI621</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd="></a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH421</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd="></a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GRS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CH621</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CJ101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PRIN CRIM JUST</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WALTERS-SLEY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  11</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SOC">SOC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B57</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CJ351</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CRIMINAL LAW</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BRYANT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   5</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">218</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CJ512</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SEXUAL VIOLENCE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ROUSSEAU</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  11</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">152</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PS512</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CJ570</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CRIM&amp;CRIMEPOLCY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CADIGAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  23</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B55</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CJ590</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CJRESEARCH&amp;EVAL</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CRONIN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  25</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=COM">COM</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">217</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CJ610</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CYBER CRIME</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LEE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   6</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">326</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CJ612</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CRIM ANALYSIS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CRONIN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   9</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">121</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS200</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTRO TO C.I.S.</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SHAHOSSINI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  15</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STH">STH</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B22</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS201</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTRO TO PROGRM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">KEKLAK</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  14</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B55</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS231</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PROGRMING W/C++</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HADAVI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  10</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">228</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS232</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PRGRMING W/JAVA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">TIZIO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  16</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">515</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS232</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS232</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PRGRMING W/JAVA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">TIZIO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   6</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">515</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS232</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS248</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DISCRETE MATH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NAIDJATE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  27</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">216</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS248</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS248</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DISCRETE MATH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NAIDJATE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   6</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">216</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS248</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS341</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DATA STR W/C++</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MASLANKA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   7</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">228</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS342</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DATA STR W/JAVA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BERRY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  20</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MCS">MCS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B37</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS401</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INT WEB APP DEV</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SHEEHAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">426</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS601</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS422</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ADV PROG CONC</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RAWASSIZADEH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">227</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS622</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS469</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INT DB &amp; IMP BS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MAIEWSKI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">229</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS669</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS472</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">COMPUTER ARCH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HENDRICKSON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  19</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">324</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS473</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTRO SOFT ENG</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ZHANG</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SHA">SHA</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">206</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS673</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS520</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INFO STR W/JAVA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DONALD</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  17</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">220</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS520</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS520</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INFO STR W/JAVA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DONALD</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">220</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS520</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS521</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INFO STR PYTHON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LU</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  38</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">527</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS521</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INFO STR PYTHON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PINSKY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  40</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=KCB">KCB</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">104</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS521</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INFO STR PYTHON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BURSTEIN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  39</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B36</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS521</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INFO STR PYTHON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ALEKSANDROV</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  28</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">201</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS526</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DATA STRUC&amp;ALGO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LEE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  39</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">203</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS535</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">COMP NETWORKS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DAY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  14</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B55</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS544</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FOUND ANALYTICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">KALATHUR</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  59</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B20</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS544</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FOUND ANALYTICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">KALATHUR</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  45</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PHO">PHO</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">211</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS546</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTRO PROB&amp;STAT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GORLIN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  30</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">214</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS546</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTRO PROB&amp;STAT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GORLIN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">316</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS546</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS546</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTRO PROB&amp;STAT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GORLIN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">316</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS546</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS555</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DATA ANALYS VIS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ALIZADEH-SHA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  16</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">213</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS555</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DATA ANALYS VIS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RAGHU</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">233</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS555</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DATA ANALYS VIS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ZHANG</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  40</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Fri</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/17/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">203</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS566</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ANALYS OF ALGRT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BELYAEV</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  35</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B53</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS566</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ANALYS OF ALGRT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BELYAEV</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  32</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Sat</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/18/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">326</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS566</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ANALYS OF ALGRT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ORSINI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  39</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=EPC">EPC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">209</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS575</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">OPRTNG SYSTEMS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NOURAI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  23</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">527</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS575</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">OPRTNG SYSTEMS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NOURAI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  25</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">527</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS575</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS575</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">OPRTNG SYSTEMS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NOURAI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   7</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">527</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS575</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS579</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DATABASE MGMNT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LEE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  36</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">123</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS581</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HEALTH INFO SYS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LEVINGER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  14</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B37</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS581</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS581</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HEALTH INFO SYS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LEVINGER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B37</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS581</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS601</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WEB APP DEVELOP</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SHEEHAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  23</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">426</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS401</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS602</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SERVER WEB DEV</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SHEEHAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  17</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">220</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS622</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ADV PROG TECH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RAWASSIZADEH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  23</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">227</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS422</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS625</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BUS DATA COM NW</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ARENA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  32</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STH">STH</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">113</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS625</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BUS DATA COM NW</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ARENA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  26</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=EPC">EPC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">204</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS633</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SFTW QUAL MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ELENTUKH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  23</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">408</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS633</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS633</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SFTW QUAL MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ELENTUKH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   7</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">408</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS633</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS634</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AGILE SFTWR DEV</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HEDA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  12</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B06A</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS662</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">COMP LANG THEOR</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NAIDJATE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  31</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">426</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS664</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ART INTELLIGNCE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BERRY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  24</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STH">STH</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B22</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS665</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SW DESIGN &amp; PAT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ORSINI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  11</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B06A</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS669</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DB DES IMP BUS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MAIEWSKI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  39</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">229</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS469</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS669</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DB DES IMP BUS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RUSSO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  33</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">226</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS669</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DB DES IMP BUS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MATTHEWS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  36</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">229</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS669</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS669</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DB DES IMP BUS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MATTHEWS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">229</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS669</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A3</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS673</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SOFTWARE ENG</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ZHANG</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  26</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SHA">SHA</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">206</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS473</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS677</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DATA SCI PYTHON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ALIZADEH-SHA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  36</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">426</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS677</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DATA SCI PYTHON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PINSKY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  37</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">315</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS682</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INFO SYS ANALYS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GUADAGNO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  25</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PHO">PHO</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">201</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS682</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INFO SYS ANALYS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GUADAGNO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  27</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SAR">SAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">300</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS682</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS682</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INFO SYS ANALYS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GUADAGNO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SAR">SAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">300</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS682</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS683</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MOBIL-APP-DEVEL</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ZHANG</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SOC">SOC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B59</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS683</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS683</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MOBIL-APP-DEVEL</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ZHANG</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   0</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SOC">SOC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B59</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS683</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS688</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WEB ANALYT MIN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RAWASSIZADEH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  40</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS688</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WEB ANALYT MIN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">VASILKOSKI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  18</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MUG">MUG</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">205</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS689</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DES DATA WAREHS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RUSSO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  34</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=KCB">KCB</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">102</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS690</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NETWRK SECURITY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MATTHEWS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   7</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">315</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS690</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS690</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NETWRK SECURITY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MATTHEWS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   6</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">315</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS690</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS693</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DGTL FORENSICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ARENA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  10</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Sat</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/18/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS695</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ENTPR CYBER SEC</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ZHANG</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS695</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS695</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ENTPR CYBER SEC</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ZHANG</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS695</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS699</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DATA MINING</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LEE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  49</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">216</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS767</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MACHINE LRNING</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ALIZADEHSHAB</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  26</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=EPC">EPC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">204</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS777</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BIG DATA ANALYS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DJORDJEVIC</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   0</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STH">STH</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">113</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS779</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ADV D-B MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">POLNAR</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  30</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">324</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS782</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">IT STRAT &amp; MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ARAKELIAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  31</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">123</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CS789</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CRYPTOGRAPHY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PASCOE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  15</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">212</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EC391</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTERNTL ECON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MOOKIM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SHA">SHA</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">206</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EN104</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ENGLISH COMPOST</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GRABIANOWSKI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SOC">SOC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B65</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EN175</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FILM &amp; LIT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">STOKES</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  14</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SOC">SOC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B61</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EN201</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTERMED COMP</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BENNETT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SOC">SOC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B67</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HI215</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SPECIAL TOPICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DEESE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   7</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SAR">SAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">104</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HI286</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WAR: SCI &amp; MED</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ALPERT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  19</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SHA">SHA</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">201</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">IS401</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">COMM SKILLS 1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GOMEZ</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  11</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">311</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LX250</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTRO LING</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LINDSEY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">522</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LX250</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LX501</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PHONET &amp; PHONOL</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LINDSEY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">233</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LX301</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd="></a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GRS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LX601</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LX521</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SYNTAX</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">DALI</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Sat</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/18/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PHO">PHO</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">205</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LX321</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd="></a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GRS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">LX621</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MA113</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ELEM STATISTICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">TAZI-NAIM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">214</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MA120</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">APPLIED MATH</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">TAZI-NAIM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   7</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">222</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MA123</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CALCULUS 1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MARCQ</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   5</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B39</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MA123</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MA123</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CALCULUS 1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MARCQ</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B39</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MA123</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MA581</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PROBABILITY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WEINER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  27</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">235</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MA603</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SAS W/STAT APP</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GOVONLU</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  14</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B25B</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG315</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">OPERATIONS MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BELLEFEUILLE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   9</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MCS">MCS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B33</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG415</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PROJECT MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RUSSELL</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  24</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">152</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG415</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG415</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PROJECT MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RUSSELL</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">152</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG415</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG431</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTL MARKETING</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BILLINGTON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  29</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">212</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG435</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ADVERTISING</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GRENON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  22</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SCI">SCI</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">115</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG448</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ELECCOMM&amp;WEBDES</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">APPELTANS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  44</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">152</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG472</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FINANCE CONCEPT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MCGUE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  12</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">222</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG472</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd="></a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD632</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG472</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FINANCE CONCEPT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MCGUE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   5</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=HAR">HAR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">222</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG472</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd="></a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD632</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG503</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BUS IN CHG SOC</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">APPELTANS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Sat</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/18/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG503</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG503</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BUS IN CHG SOC</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">APPELTANS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   5</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Sat</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/18/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">101</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG503</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG515</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NEGOT CONFL RES</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MARYA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  13</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12:00PM -  2:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=MET">MET</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG520</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTL BUS MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GIL VASQUEZ</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  22</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STH">STH</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B22</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG520</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG520</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EX</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTL BUS MGMT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GIL VASQUEZ</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STH">STH</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B22</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG520</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG541</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INNOVT PRS:PR&amp;S</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PARK</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  44</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SCI">SCI</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">117</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG541</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INNOVT PRS:PR&amp;S</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BONYHAY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  24</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=COM">COM</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">111</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG545</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AMER INSTI CULT</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ROBERTSON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  36</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 3:00PM -  5:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">152</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MG550</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTL BUS LAW</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">BARRY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  18</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">216</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">AD746</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ML610</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SPECIAL TOPICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">RAHN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  11</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">212</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ML636</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CULT&amp;CUIS:ITALY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ESPOSITO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   6</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Sat</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/18/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 9:00AM - 11:00AM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">114B</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ML651</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WINE FUNDAMNTLS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NESTO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=NIP">NIP</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">320</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ML652</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SURVEY OF WINE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NESTO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   4</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ML655</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FOOD BUSINESS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WARD</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   8</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=PSY">PSY</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">212</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ML681</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">FOOD WRTG MEDIA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">JULIAN</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   9</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Mon</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/13/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">122</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ML702</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">E1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SPECIAL TOPICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CATALANO</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">124</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PH150</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">INTRO TO ETHICS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">NIIZAWA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   5</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=STH">STH</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">441</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PH248</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EXISTENTIALISM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">KINKAID</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   6</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=KCB">KCB</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">107</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PS326</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">EXP PSY SOCIAL</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">WEAVER</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   7</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SCI">SCI</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">115</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PS512</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SEXUAL VIOLENCE</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ROUSSEAU</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  10</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=FLR">FLR</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">152</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CJ512</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PY105</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">S5</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">ELEM PHYSICS 1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MOHANTY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   3</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=SCI">SCI</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B23</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PY211</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GEN PHYSICS 1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">JARIWALA</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   0</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">211</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PY211</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">313</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PY211</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B12</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PY212</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">C1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GEN PHYSICS 2</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SUAREZ</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">   0</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">129</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PY212</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">511</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PY212</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">B1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd="></a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">CAS</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PY212</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">C1</font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">UA503</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">HOUSING&amp;COM DEV</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">KWON</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  19</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Thu</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/16/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CAS">CAS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">326</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">UA664</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">PLAN &amp; DEV PROC</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">GREELEY</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  29</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Wed</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/15/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=CGS">CGS</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">515</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        
        <tr align="center" valign="top">
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">MET</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">UA703</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">A1</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">URBAN RES METHD</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">SUNGU-ERYILM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">  25</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">Tue</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">12/14/21</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"> 6:00PM -  8:00PM</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"><a href="https://www.bu.edu/link/bin/uiscgi_studentlink.pl/1639083371?applpath=bldg.pl&amp;BldgCd=EPC">EPC</a></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif">205</font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td>
          <td align="LEFT"><font size="-1" color="#330000" face="Verdana, Helvetica, Arial, sans-serif"></font></td></tr>
        </tbody></table>`,
      }}
    />
  )
}

export default UniFinalExam
